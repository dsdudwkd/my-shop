import React from 'react';
import Products from '../component/Products';

function AllProduct(props) {
    return (
        <div className='container'>
           <Products /> 
        </div>
    );
}

export default AllProduct;